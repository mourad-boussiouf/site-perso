<h3>Formulaire contact</h3>
<table>
    <tr>
        <th>Nom</th>
        <td>{{ $name }}</td>
    </tr>
    <tr>
        <th>Email</th>
        <td>{{ $email }}</td>
    </tr>
</table>

<div>
    {{$body}}
</div>
