<li>
    <a href="{{ $href }}" class="text-base font-medium text-dark hover:text-primary py-2 lg:inline-flex flex lg:ml-12">
        {{ $slot }}
    </a>
</li>
