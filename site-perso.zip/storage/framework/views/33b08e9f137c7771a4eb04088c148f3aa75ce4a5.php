<input

    <?php echo e($attributes->class([
            'w-full
            rounded
            py-3
            px-[14px]
            text-body-color text-base
            border border-[f0f0f0]
            outline-none
            focus-visible:shadow-none
            focus:border-primary
           '
        ])); ?>


/>
<?php /**PATH /var/www/html/resources/views/components/forms/input.blade.php ENDPATH**/ ?>