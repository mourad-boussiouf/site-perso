<link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Hero::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Hero::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570)): ?>
<?php $component = $__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570; ?>
<?php unset($__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CallToAction::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('call-to-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CallToAction::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('title', null, []); ?> 
            <span class="text-white text-base font-semibold mb-2">
                Faites confiance à la performance
            </span>
            <h2
                class=" text-white font-bold text-3xl sm:text-[37px] leading-tight mb-6 sm:mb-8 lg:mb-0 "
            >Mon objectif : sécurité, accessibilité. <br class="hidden xs:block"/>
                Développeur web passionné. Stack : PHPw/laravel, JS, linux, docker.
            </h2>
             <?php $__env->endSlot(); ?>
            <a
                href="#contact"
                class=" inline-block py-4 px-6 md:px-9 lg:px-6 xl:px-9 rounded text-base font-medium bg-gray-900 hover:bg-gray-800 text-white mr-4 my-1 transition "
            >

                Me contacter
            </a>
            <a
                href="https://www.dailymotion.com/mouradddex"
                class=" inline-block py-4 px-6 md:px-9 lg:px-6 xl:px-9 rounded text-base font-medium bg-red-700 transition hover:bg-opacity-90 text-white my-1 "
            >
                Ma chaine dailymotion
            </a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa)): ?>
<?php $component = $__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa; ?>
<?php unset($__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalbd1b424d9d6d0a9b69acee2535d60f75a038172c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\QuisuisjeSection::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('quisuisje-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\QuisuisjeSection::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd1b424d9d6d0a9b69acee2535d60f75a038172c)): ?>
<?php $component = $__componentOriginalbd1b424d9d6d0a9b69acee2535d60f75a038172c; ?>
<?php unset($__componentOriginalbd1b424d9d6d0a9b69acee2535d60f75a038172c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal1e7e95ea22fba7050fb121d3afe847c394e1e707 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Portfolio::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.portfolio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Home\Portfolio::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e7e95ea22fba7050fb121d3afe847c394e1e707)): ?>
<?php $component = $__componentOriginal1e7e95ea22fba7050fb121d3afe847c394e1e707; ?>
<?php unset($__componentOriginal1e7e95ea22fba7050fb121d3afe847c394e1e707); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.home.contact','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>