<!-- ====== Hero Section Start -->
<div class="relative pt-[60px] lg:pt-[80px] pb-[110px] bg-white dark:bg-slate-800">
    <div class="container">
        <div class="flex flex-wrap -mx-4">
            <div class="w-full lg:w-5/12 px-4">
                <div class="hero-content">
                    <h1
                        class="text-dark dark:text-gray-200 font-bold text-4xl sm:text-[42px] lg:text-[40px] xl:text-[42px] leading-snug mb-6"
>
                        <br/>
                        <br/>
                        <br/>
Mourad BOUSSIOUF <br/>
                        <span class="px-2 rounded-md text-amber-600">web_dev</span>

                    </h1>
                    <p class="text-base dark:text-gray-400 mb-8  max-w-[480px] ">
Je suis un développeur web agé de 24 ans.<br> Né et basé à Marseille.<br>
En apprentissage quotidien depuis 2 ans et pour encore longtemps.<br> Également étudiant à La plateforme, grande école du numérique, ce site présente mon parcours ainsi que mes projets.
                    </p>
                    <ul class="flex flex-wrap items-center">
                        <li>
                            <?php if (isset($component)) { $__componentOriginalbb0329fb69c9d7b0def433d126d4babcbbf6a794 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ButtonLink::class, ['href' => '#portfolio','variant' => 'primary'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ButtonLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'rounded-lg']); ?>
                                Mes projets
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0329fb69c9d7b0def433d126d4babcbbf6a794)): ?>
<?php $component = $__componentOriginalbb0329fb69c9d7b0def433d126d4babcbbf6a794; ?>
<?php unset($__componentOriginalbb0329fb69c9d7b0def433d126d4babcbbf6a794); ?>
<?php endif; ?>
                        </li>
                    </ul>
                    <div class="clients pt-24">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.social-icons','data' => ['class' => 'mb-0']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('social-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-0']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <div class="flex items-center">
                        </div>
                    </div>
                </div>
            </div>
            <div class="hidden lg:block lg:w-1/12 px-4">
            </div>
            <div class="w-full lg:w-6/12 px-10">
                </br>
                </br>
                </br>
                <div class="lg:text-right lg:ml-auto">

                    <div class="relative inline-block z-20 pt-20 lg:pt-0 -bottom-7">

                        <img
                            src="https://i.ibb.co/QdwvXY7/imgportfolio1.png"
                            alt="hero"
                            class="max-w-full lg:ml-auto "
                        />
                        <span class="absolute -left-8 -bottom-8 z-[-1]">
                          <svg
                              width="93"
                              height="93"
                              viewBox="0 0 93 93"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                          >
                            <circle cx="2.5" cy="2.5" r="2.5" fill="#3056D3"/>
                            <circle cx="2.5" cy="24.5" r="2.5" fill="#3056D3"/>
                            <circle cx="2.5" cy="46.5" r="2.5" fill="#3056D3"/>
                            <circle cx="2.5" cy="68.5" r="2.5" fill="#3056D3"/>
                            <circle cx="2.5" cy="90.5" r="2.5" fill="#3056D3"/>
                            <circle cx="24.5" cy="2.5" r="2.5" fill="#3056D3"/>
                            <circle cx="24.5" cy="24.5" r="2.5" fill="#3056D3"/>
                            <circle cx="24.5" cy="46.5" r="2.5" fill="#3056D3"/>
                            <circle cx="24.5" cy="68.5" r="2.5" fill="#3056D3"/>
                            <circle cx="24.5" cy="90.5" r="2.5" fill="#3056D3"/>
                            <circle cx="46.5" cy="2.5" r="2.5" fill="#3056D3"/>
                            <circle cx="46.5" cy="24.5" r="2.5" fill="#3056D3"/>
                            <circle cx="46.5" cy="46.5" r="2.5" fill="#3056D3"/>
                            <circle cx="46.5" cy="68.5" r="2.5" fill="#3056D3"/>
                            <circle cx="46.5" cy="90.5" r="2.5" fill="#3056D3"/>
                            <circle cx="68.5" cy="2.5" r="2.5" fill="#3056D3"/>
                            <circle cx="68.5" cy="24.5" r="2.5" fill="#3056D3"/>
                            <circle cx="68.5" cy="46.5" r="2.5" fill="#3056D3"/>
                            <circle cx="68.5" cy="68.5" r="2.5" fill="#3056D3"/>
                            <circle cx="68.5" cy="90.5" r="2.5" fill="#3056D3"/>
                            <circle cx="90.5" cy="2.5" r="2.5" fill="#3056D3"/>
                            <circle cx="90.5" cy="24.5" r="2.5" fill="#3056D3"/>
                            <circle cx="90.5" cy="46.5" r="2.5" fill="#3056D3"/>
                            <circle cx="90.5" cy="68.5" r="2.5" fill="#3056D3"/>
                            <circle cx="90.5" cy="90.5" r="2.5" fill="#3056D3"/>
                          </svg>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ====== Hero Section End -->
<?php /**PATH /var/www/html/resources/views/components/hero.blade.php ENDPATH**/ ?>