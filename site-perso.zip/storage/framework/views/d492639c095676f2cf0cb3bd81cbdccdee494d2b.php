<h3>Formulaire contact</h3>
<table>
    <tr>
        <th>Nom</th>
        <td><?php echo e($name); ?></td>
    </tr>
    <tr>
        <th>Email</th>
        <td><?php echo e($email); ?></td>
    </tr>
</table>

<div>
    <?php echo e($body); ?>

</div>
<?php /**PATH /var/www/html/resources/views/email/contact.blade.php ENDPATH**/ ?>