<li>
    <a href="<?php echo e($href); ?>" class="text-base font-medium text-dark hover:text-primary py-2 lg:inline-flex flex lg:ml-12">
        <?php echo e($slot); ?>

    </a>
</li>
<?php /**PATH /var/www/html/resources/views/layout/navbar-item.blade.php ENDPATH**/ ?>